export class empModel {
    id: number = 0
    empName: string = ''
    empNo: number = 0
    profile: string = ''
    gender: string = ''
    dob: string = ''
    age: number = 0
    emailId: string = ''
    mobileNo: number = 0
    address: string = ''
    bloodGroup: string = ''
    password: string = ''
}