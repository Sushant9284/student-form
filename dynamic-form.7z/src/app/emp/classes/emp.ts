export class emp {
    id: number
    empName: string
    empNo: number
    profile: string
    gender: string
    dob: string
    age: number
    emailId: string
    mobileNo: number
    address: string
    bloodGroup: string
    password: string 
}