export class student {
    rollNo: number
    name: string
    dob: string
    address: string
    email: string
    phoneNo: string
}